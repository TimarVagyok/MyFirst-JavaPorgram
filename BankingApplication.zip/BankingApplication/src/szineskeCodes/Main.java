/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package szineskeCodes;

import java.util.Scanner;

/**
 *
 * @author abdullah majid
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        System.out.println("Creating new bank account........\nWhat is your first name?\n");
        String a=sc.nextLine();
        System.out.println("Choose and ID\n");
        String b=sc.nextLine();
        System.out.println("Choose a password");
        String c= sc.nextLine();
        BankAccount B1 = new BankAccount(a,b,c);
        String Id ;
        String password ;
        do{
            System.out.println("Hello what is your ID please?\n");
            Id = sc.nextLine();
            System.out.println("\n");
            System.out.println("What is your password? \n");
            password = sc.nextLine();
            System.out.println("\n");
             if (B1.getCusomerID().equals(Id) && B1.getPassword().equals(password))
             {
                  B1.showMenu();
                  break ;
             }
             if(password.equals("A"))
             {
                 System.out.println("Please try to contact the customer service");
                 break;
             }
             if (!B1.getCusomerID().equals(Id) || !B1.getPassword().equals(password))
             {
                 System.out.println("Not correct, please try again\n");
             }

        } while(!password.equals("A"));
        
    }
    
}
