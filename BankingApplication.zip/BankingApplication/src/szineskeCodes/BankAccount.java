
package szineskeCodes;

import java.util.Scanner;

/**
 *
 * @author abdullah majid
 */
public class BankAccount {
    private int balance;
    private int lastTransaction;
    private String customerName;
    private String cusomerID;
    private String Password;

    public BankAccount(String customerName, String cusomerID, String Password) {
        this.customerName = customerName;
        this.cusomerID = cusomerID;
        this.Password = Password;
    }

    public String getCusomerID() {
        return cusomerID;
    }


    public String getPassword() {
        return Password;
    }

    
    void deposit(int amount){
        if (amount != 0)
        {
        balance = balance + amount ;
        lastTransaction = amount;
        }
    }
    void withdraw(int amount)
    {
        if(amount != 0){
            balance = balance - amount;
            lastTransaction = -amount;
        }
    }

    void getLastTransaction()
    {
        if(lastTransaction > 0)
        {
            System.out.println("Deposited: "+ lastTransaction);
        }
        else if(lastTransaction < 0){
            System.out.println("Withdrawn: "+ Math.abs(lastTransaction));
        }
        else
        {
            System.out.println("No transacion occured");
        }
    }
    void showMenu()
    {
         char option = '\0';
         Scanner sc = new Scanner(System.in);
         System.out.println("Welcome "+ customerName);
         System.out.println("Your ID is " + cusomerID);
         do 
         {
             System.out.println("A. Check Balance");
             System.out.println("B. Deposit");
             System.out.println("C. Withdraw");
             System.out.println("D. Previous Transaction");
             System.out.println("E. Exit");
             System.out.println("===========================================================");
             System.out.println("Enter an option");
             System.out.println("===========================================================");
             option = sc.next().charAt(0);
             System.out.println("\n");
             
             switch(option)
             {
                 case 'A':
                 case 'a':
                     System.out.println("-----------------------------------------");
                     System.out.println("Your Balance is :"+ balance);
                     System.out.println("-----------------------------------------");
                     System.out.println("\n");
                     break;
                 case 'B':
                 case 'b':
                     System.out.println("-----------------------------------------");
                     System.out.println("Enter an amount to deposit");
                     System.out.println("-----------------------------------------");
                     int amount1 =sc.nextInt();
                     deposit(amount1);
                     System.out.println("\n");
                     break;
                 case 'C':
                 case 'c':
                     System.out.println("-----------------------------------------");
                     System.out.println("Enter an amount to Withdraw");
                     System.out.println("-----------------------------------------");
                     int amount2 = sc.nextInt();
                     withdraw(amount2);
                     System.out.println("\n");
                     break;
                 case'D':
                 case'd':
                     System.out.println("-----------------------------------------");
                     getLastTransaction();
                     System.out.println("-----------------------------------------");
                     System.out.println("\n");
                     break;
                 case 'E':
                 case 'e':
                     System.out.println("*************************");
                     break;
                 default:
                     System.out.println(" Invalid Opetion! please inter a valid option ");
                     break;
             }
             
         } while(option != 'E' && option !='e');
         System.out.println("Thank you for using our services "+ customerName);
    }
    
}
